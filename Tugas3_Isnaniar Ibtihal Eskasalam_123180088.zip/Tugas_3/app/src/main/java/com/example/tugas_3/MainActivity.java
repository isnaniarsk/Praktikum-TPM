package com.example.tugas_3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rvGroup;
    private ArrayList<Group> groups = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvGroup = findViewById(R.id.rvGroup);
        rvGroup.setHasFixedSize(true);

        groups.addAll(DataGroup.getDataGroup());
        showRecyclerView();
    }

    private void showRecyclerView() {
        // inisialisasi layout pada recyclerView dengan orientasi linear vertikal tiap satu item
        rvGroup.setLayoutManager(new LinearLayoutManager(this));
        // inisialisasi adapter dengan parameter data yang telah ditampung
        DataAdapter listHeroAdapter = new DataAdapter(groups, this);
        // memasukkan adapter yang telah dibuat kedalam recyclerView
        rvGroup.setAdapter(listHeroAdapter);
    }
}